class Product {
  final String ma;
  final String ten;
  final String maVach;
  final String tenLoaiHang;
  final int soLuong;
  final int nguongCanhBao;
  final String donViTinh;
  final String giaBan;
  final String phanTramLoiNhuan;
  bool isDeleted;

  Product({
    required this.ma,
    required this.ten,
    required this.maVach,
    required this.tenLoaiHang,
    required this.soLuong,
    required this.nguongCanhBao,
    required this.donViTinh,
    required this.giaBan,
    required this.phanTramLoiNhuan,
    this.isDeleted = false,
  });
}

